import react from 'react';
class RemoveCart extends react.Component{
    render()
    {
        return(<div>
            <button className="btn btn-success" >Remove</button>

        </div>)
    }
}

export default RemoveCart;